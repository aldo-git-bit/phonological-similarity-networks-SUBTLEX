# SUBTLEX-US

pip install openpyxl

# Thanks Sarbjot!
